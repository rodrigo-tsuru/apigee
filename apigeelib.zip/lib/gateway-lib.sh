#!/bin/bash
source "${APIGEE_ROOT}/apigee-lib/apigee-lib.sh" || exit 1

# @TODO don't really like this, because of global variables and also uses functions from apigee-lib/apige-lib.sh

create_token_file(){
    local TOKEN_FILE="$1"
    PARENT_DIR=$(dirname "${TOKEN_FILE}")
    if [ ! -d "${PARENT_DIR}" ]; then
        mkdir -p "${PARENT_DIR}"
    fi
    if [ ! -f "${TOKEN_FILE}" ]; then
        touch "${TOKEN_FILE}"
    fi
}

copy_license(){
    local rt=0
    # Install license file
    local DONE=0
    while [ $DONE -eq 0 ]; do
        get_var LICENSE_FILE "Enter fully qualified path to Apigee license file" mand="y"
        if [ -f "${LICENSE_FILE}" ]; then
          echo -e "\nCopying ${LICENSE_FILE} to ${APIGEE_ROOT}/customer/conf/license.txt \n"
          replace_file "${APIGEE_ROOT}/customer/conf/license.txt" "${LICENSE_FILE}" 
          rt=$?
          DONE=1
        else
          echo "Error: license file '${LICENSE_FILE}' cannot be read"
          LICENSE_FILE=""
        fi
    done
    return $rt    
}


# @brief encrypts the password passed in
# Is assumes that APIGEE_ROOT is set
# @param PASSWD - the password to encrypt
# outputs the encrypted password
# returns 1 on error 0 if not
encrypt_password() {
    local PASSWD=$1
    local AX_ENC=${2:-false}
    local ENCPWD
    # # # # # # # # # # # # # # # # # # #
    # Configure security and credentials
    # # # # # # # # # # # # # # # # # # #
    KR="${APIGEE_ROOT}"/edge-gateway/lib/kernel
    IS="${APIGEE_ROOT}"/edge-gateway/lib/infra/services
    TP="${APIGEE_ROOT}"/edge-gateway/lib/thirdparty
    IL="${APIGEE_ROOT}"/edge-gateway/lib/infra/libraries
    CF="${COMPONENT_ROOT}/conf"
    CLASSPATH="${TP}/*:${IS}/*:${KR}/*:${IL}/*:${CF}:"

    if [ "${AX_ENC}" == "false" ]; then
        ENCPWD="$(java -cp "$CLASSPATH" com.apigee.util.CredentialUtil \
            user='' --password="${PASSWD}" --passphrase=''| tail -n1)"
    else
        ENCPWD="$(java -cp "$CLASSPATH" com.apigee.util.des.DESMaskingUtil \
            ${PASSWD} | grep "Encrypted string :" | sed -e "s/Encrypted string ://g")"
    fi
    
    if [ $? -ne 0 ] || [ -z "${ENCPWD}" ]; then
        exit 1
    fi
    echo "$ENCPWD"
}

# @brief updates the tokens
# conf_credentials_cassandra.user
# conf_credentials_cassandra.password
# @param TOKEN_FILE to update
# @param CASS_USERNAME cassandra username can be blank
# @param CASS_PASSWORD cassandra password can be blank
# in the token file passed in
# it will encrypt the password first before setting the token
# if CASS_USERNAME is passed in as null, won't update token
# if CASS_PASSWORD is passed in as null, won't update token
# encrypt_password expects that the global variabel APIGEE_ROOT is defined and correct
store_cassandra_credentials() {
  local TOKEN_FILE=$1
  local CASS_USERNAME=$2
  local CASS_PASSWORD=$3
  if [ -n "$CASS_PASSWORD" ]; then
    ENCPWD=$(encrypt_password "$CASS_PASSWORD")
    RT=$?
    if ((RT)); then
          echo "Error: encrypting password"
          return 1
    fi
    update_property "${TOKEN_FILE}" "conf_credentials_cassandra.password=${ENCPWD}" || exit 1
  fi  

  if [ -n  "$CASS_USERNAME" ]; then
      update_property "${TOKEN_FILE}" "conf_credentials_cassandra.user=${CASS_USERNAME}" || exit 1
  fi

} 

# @brief updates the tokens
# conf_security_ldap.server.admin.password
# @param TOKEN_FILE to update
# @param LDAP_PASSWORD ldap password can be blank
# in the token file passed in
# it will encrypt the password first before setting the token
# if LDAP_PASSWORD is passed in as null, won't update token
# encrypt_password expects that the global variabel APIGEE_ROOT is defined and correct
store_ldap_credentials() {
  local TOKEN_FILE=$1
  local LDAP_PASSWORD=$2
  if [ -n "$LDAP_PASSWORD" ]; then
    ENCPWD=$(encrypt_password "$LDAP_PASSWORD")
    RT=$?
    if ((RT)); then
          echo "Error: encrypting password"
          return 1
    fi
    update_property "${TOKEN_FILE}" "conf_security_ldap.server.admin.password=${ENCPWD}" || exit 1
  fi  
} 


update_pg_properties(){
    local TOKEN_FILE=$1
    # Should be set if run through apigee-service
    RUN_USER=${RUN_USER:-apigee}

    # Encrypt pg password
    ENCPWD=$(encrypt_password "$PG_PWD" "true")

    update_property "${TOKEN_FILE}" "conf_query-service_pgDefaultUser=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_query-service_dwDefaultUser=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_analytics_aries.pg.username=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_pg-ingest_userName=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_pg-agent_userName=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_pg-agent_password=${ENCPWD}"
    update_property "${TOKEN_FILE}" "conf_pg-ingest_password=${ENCPWD}"
    update_property "${TOKEN_FILE}" "conf_query-service_pgDefaultPwd=${ENCPWD}"
    update_property "${TOKEN_FILE}" "conf_query-service_dwDefaultPwd=${ENCPWD}"
    update_property "${TOKEN_FILE}" "conf_analytics_aries.pg.password=${ENCPWD}"
}

update_ms_properties(){
    local PROFILE="management-server"
    local TOKEN_FILE=$1
    RUN_USER=${RUN_USER:-apigee}
 
    [ -z "${READ_QUORUM}" ]  && READ_QUORUM="LOCAL_QUORUM"
    [ -z "${WRITE_QUORUM}" ] && WRITE_QUORUM="LOCAL_QUORUM"

    # Update conf/system.properties
    update_property "${TOKEN_FILE}" "conf_system_profile=$PROFILE"
    
    # ?? is that the right token
    update_property "${TOKEN_FILE}" "conf_keymanagement-datastore-config_read.consistencylevel=${READ_QUORUM}"
    update_property "${TOKEN_FILE}" "conf_keymanagement-datastore-config_write.consistencylevel=${WRITE_QUORUM}"
    # update kms cache memory enabled
    # IN DEFAULTS update_property "${TOKEN_FILE}" "conf_keymanagement_kms_cache_memory_element_enable=true"

    LDAPPW=${LDAPPW:-${APIGEE_LDAPPW:-$(get_input "Enter root password for LDAP" mand="y" hidden="y" verify="y")}}

    BIND_DN=${APIGEE_BIND_DN:-cn=manager,dc=apigee,dc=com}
    update_property "${TOKEN_FILE}" "conf_security_ldap.server.admin.dn=$BIND_DN"
    update_property "${TOKEN_FILE}" "conf_security_ldap.server.host=${LDAP_HOST}"
    
    store_ldap_credentials  "${TOKEN_FILE}" "$LDAPPW"
    
    update_property "${TOKEN_FILE}" "conf_security_ui.emailid=${ADMIN_EMAIL}"

    if [ ! -z "${LDAP_PORT}" ]; then
      update_property "${TOKEN_FILE}" "conf_security_ldap.server.port=${LDAP_PORT}"
    fi
    if [ ! -z "${APIGEE_PORT_HTTP_MS}" ]; then
      update_property "${TOKEN_FILE}" "conf_webserver_http.port=${APIGEE_PORT_HTTP_MS}"
    fi 

    # Encrypt pg password
    ENCPWD=$(encrypt_password "$PG_PWD" "true")

    update_property "${TOKEN_FILE}" "conf_query-service_pgDefaultUser=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_query-service_dwDefaultUser=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_analytics_aries.pg.username=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_pg-ingest_userName=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_pg-agent_userName=${RUN_USER}"
    update_property "${TOKEN_FILE}" "conf_pg-agent_password=${ENCPWD}"
    update_property "${TOKEN_FILE}" "conf_pg-ingest_password=${ENCPWD}"
    update_property "${TOKEN_FILE}" "conf_query-service_pgDefaultPwd=${ENCPWD}"
    update_property "${TOKEN_FILE}" "conf_query-service_dwDefaultPwd=${ENCPWD}"
    update_property "${TOKEN_FILE}" "conf_analytics_aries.pg.password=${ENCPWD}"
}

##
## this function (among other things) configures the files
##   $INSTALL_DIR/etc/init.d/apigee-$prf
##   $APIGEE_CONF_DIR/$prf/*.properties
## although some of the operations it uses are individually
## non-idempotent, the process begins by making a fresh copy
## of the files.  thus the function may be called more than
## once without messing up the files.
#
## create_profile
update_properties() {
    local TOKEN_FILE="$1"
    local PROFILE="$2"
    local REGION="$3"
    local CASS_USERNAME="$4"
    local CASS_PASSWORD="$5"
    local MS="management-server"
    local PG="postgres-server"
    local QS="qpid-server"

    # The following change is required to be backward compatible. In case customer's silent.conf does not have PG_PWD defined
    PG_PWD=${PG_PWD:-postgres}

    # # # # # # # # # # # # # # # # # # #
    # Configure zookeeper and cassandra
    # # # # # # # # # # # # # # # # # # #

    # ZK Client properties
    local CONN_STRING="${ZK_CLIENT_HOSTS// /:2181,}:2181/"

    update_property "${TOKEN_FILE}" "conf_zookeeper_connection.string=${CONN_STRING}"
    
    # # # # # # # # # # # # # # #
    # Configure other properties
    # # # # # # # # # # # # # # #
    update_property "${TOKEN_FILE}" "conf_system_region=${REGION}"

    store_cassandra_credentials "${TOKEN_FILE}" "${CASS_USERNAME}" "${CASS_PASSWORD}"

    case "$PROFILE" in
      $MS)
        update_ms_properties "${TOKEN_FILE}" 
        ;;
      $PG)
        update_pg_properties "${TOKEN_FILE}"
        ;;
      $QS)
        update_pg_properties "${TOKEN_FILE}"
        ;;
    esac 

    return 0
}


#**
# @breif function will return the CASS HOSTS that are in the same REGION
# as the REGION that was passed in
# @param CASS_HOSTS - space seperated list of CASS_HOSTS
# @param REGION - region wanted
# @returns all the CASS_HOSTS it finds in the region
# if the CASS_HOSTS were passed in with the datacenter rack info, it will
# compare the datacenter it finds wit the REGION passed in.  If the datacenter info is just a number
# example; 10.10.1.1:1,1 - for backwards compatibility it will try do compare dc-# with REGION, since
# old installs would have the above CASS_HOSTS format
get_cass_hosts_in_region() {
    local CASS_HOSTS=($1)
    local _REGION=$2
    local REGION_CASS_HOSTS=()
    local DC_RA DC RA
    for SERVER in ${CASS_HOSTS[@]}; do
        DC_RA=${SERVER#*:}
        DC=${DC_RA%,*}
        FOUND=$(echo $SERVER | grep -c ":")
        if ! ((FOUND)); then
            REGION_CASS_HOSTS+=($SERVER)
        elif [ "$DC" == "${_REGION}" ] || [ "dc-${DC}" = "${_REGION}" ]; then
            IP=${SERVER%:*}
            REGION_CASS_HOSTS+=($IP)
        fi
    done
    echo "${REGION_CASS_HOSTS[*]}"
}


ms_reachable() {
  # if Management Server is not available don't bother
  local RESULT
  RESULT=$(ex_curl "http://${MSIP}:${APIGEE_PORT_HTTP_MS}/v1/servers/self/up" 2> /dev/null)
  HTTP_CODE=$(get_curl_returncode "$RESULT" )
  if [[ "$HTTP_CODE" -eq 200 ]]; then
    return 0
  else
    println "Error: Management Server is unavailable. Quitting"
    return 1
  fi 
  return 0
}

enter_APW() {
  local password=""
  ms_reachable

  valid=0
  nretries=0
  while [ $valid -ne 1 ]; do
     password=$(get_input "Enter system admin password" hidden=y mand=y)
     ex_curl -u "${ADMIN_EMAIL}:${password}" "http://${MSIP}:${APIGEE_PORT_HTTP_MS}/v1/servers" >/dev/null 2>&1
     if [ $? -eq 0 ]; then
        valid=1
     else
        nretries=$((nretries+1))
        if [ $nretries -gt 2 ]; then
           println "Error: Too many password attempts. Quiting"
           exit 1
        else
           println "Password invalid, please try again"
        fi
     fi
  done
  # shellcheck disable=SC2034
  APIGEE_ADMINPW=$password
}

## function get_region_pods
## get all gateway pods in a region/datacenter
# @todo - should this go into the edge-management-server?
# Entered in spreadsheet
get_region_pods() {
    local msip="$1" admin="$2" pw="$3"
    check_args  "3" "$msip $admin $pw"
    local ret=$?
    if ((ret)); then
        return 1
    fi

    regions=$(get_datacenters "${msip}" "${admin}" "${pw}")
    mp_pods=""
    for region in ${regions}; do
        result=$(ex_curl -u "${admin}:${pw}" -H "Accept: application/json" "${msip}:${APIGEE_PORT_HTTP_MS}/v1/regions/${region}/pods")
        ret=$?
        if [ ${ret} -eq 0 ]; then
            pods=$(get_curl_response "${result}" | "$OPDK_JQ" -r '.[]')
            ret=$?
            if [ ${ret} -eq 0 ]; then
                for pod in ${pods}; do
                    [ "${pod}" != "central" ] && [ "${pod}" != "analytics" ] && mp_pods="${mp_pods} ${region}:${pod}"
                done
            else
                return ${ret}
            fi
        else
            return ${ret}
        fi
    done
    println "${mp_pods}"
    return 0
}

## function get_service_details
## Get UUIDs of all services in a given region / pod
get_service_details() {
  local srvname="$1"
  local region="$2"
  local pod="$3"
  local pw="$4"

  local RESULT
  RESULT=$(ex_curl -u "${ADMIN_EMAIL}:${pw}" "http://${MSIP}:${APIGEE_PORT_HTTP_MS}/v1/servers?type=${srvname}&pod=${pod}&region=${region}" -H "Accept: application/xml" 2> /dev/null)
  if [ $? -ne 0 ]; then
    echo "${RESULT}"
    check_result 1 "n/a" "ERROR: Cannot retrieve ${srvname} info for pod ${pod}."
  fi
  local MPS
  MPS=$(get_curl_response "${RESULT}")
  local INFO
  INFO=$(python "$APIGEE_ROOT/apigee-lib/bin/get-uuid.py" "${MPS}")
  if [ "${#INFO}" == 0 ]; then
    echo ""
    return 0
  else
    local B_IFS=${IFS}
    IFS=$'\n'
    local uuids=""
    local uuid=""
    local line
    local ip
    local lines=( ${INFO} )
    for line in ${lines[*]}; do
      ip=$(get_part "${line}" 0)
      uuid=$(get_part "${line}" 4)
      port=$(get_part "${line}" 5)
      uuids="${uuids} ${uuid}:${ip}/${port}"
    done
    IFS=${B_IFS}

    # shellcheck disable=SC2086
    echo ${uuids}
    return 0
  fi
}

get_servers() {
  local SERVICE="$1"
  local DATACENTER="$2"
  local POD="$3"
  local UUID_IPS=""

  local UUID_IP
  local RESULT=""

  RESULT=$(get_service_details "${SERVICE}" "${DATACENTER}" "${POD}" "${APIGEE_ADMINPW}")
  if [ -n "${RESULT}" ]; then
    for UUID_IP in ${RESULT}; do
      UUID_IPS="${UUID_IPS}${UUID_IP} "
    done
  fi
  echo "$UUID_IPS"
  return 0
}

add_cron_entry() {
  local cmd="$1"
  local pattern="$2"
  local cron_file="$3"

  mkdir -p "${COMPONENT_ROOT}/cron"
  cron_file="${COMPONENT_ROOT}/cron/$cron_file"
  out=$(cat "$cron_file" | grep -v "$pattern")
  echo "$out" > "$cron_file"
  echo -e "$cmd" >> "$cron_file"
}

enable_jstack(){
  ENABLE_JSTACK=${ENABLE_JSTACK:-n}
  if [ "${ENABLE_JSTACK}" == "y" ]; then
    echo "adding jstack cron entry"
    # staggering the jstack cron entry
    local rand_num=$(( ( RANDOM % 4 ) ))
    CMD="\n$rand_num-59/4 * * * * ${RUN_USER} /usr/bin/flock -n /tmp/jstack.lockfile  -c '${APIGEE_ROOT}/${COMPONENT_NAME}/bin/jstack.sh -c $JAVA_HOME/bin/jstack  -p $PID_FILE -l $APIGEE_APP_LOGDIR'"
    add_cron_entry "$CMD" "${APIGEE_ROOT}/${COMPONENT_NAME}/bin/jstack.sh" "jstack.cron"

    if [ -n "$JSTACK_BUCKET" ]; then
      CMD="\n5-59/15 * * * * root ${APIGEE_ROOT}/edge-gateway/bin/push_jstack.sh $APIGEE_APP_LOGDIR $JSTACK_BUCKET $JSTACK_TMPWATCH_HRS"
      add_cron_entry "$CMD" "${APIGEE_ROOT}/edge-gateway/bin/push_jstack.sh" "jstack.cron"
    fi
  fi
  return 0
}
