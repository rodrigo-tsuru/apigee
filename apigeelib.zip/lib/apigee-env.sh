############################################################################
# This is an auto-generated file, if you would like to add variables here,
# create package/rpm/template-value.list with name=value before packaging.
############################################################################
export APPLICATION=gateway
export APIGEE_PREFIX=edge-
DESCRIPTION=" Application: gateway Release: 4.50.00 Source Commit: b89ec5150f79d4b7357946cee0859fc7534af88a"
ITERATION="0.0.20086"
LICENSE="Apigee Corp. All rights reserved."
MAINTAINER="Apigee Corporation <build@apigee.com>"
NAME="edge-gateway"
RPM_GROUP="apigee"
RPM_USER="apigee"
URL="http://www.apigee.com/docs"
VENDOR="Apigee Corp."
VERSION="4.50.00"
RUN_USER=${RUN_USER:-${RPM_USER}}
RUN_GROUP=${RPM_GROUP}
